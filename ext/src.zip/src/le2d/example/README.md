# le2d example

The example (ideally) mirrors the code in the [Getting Started](../lib/docs/getting_started.md) section of the docs. The assets are not part of the repository, you need to provide them in the working directory:

```
assets
├── audio
│   └── explode.wav
├── fonts
│   └── Vera.ttf
└── images
    └── awesomeface.png
```
