#pragma once
#include <klib/log.hpp>

namespace le {
auto const log = klib::TaggedLogger{"le"};
} // namespace le
