#pragma once
#include <klib/log.hpp>

namespace le::assed {
auto const log = klib::TaggedLogger{"le::assed"};
} // namespace le::assed
