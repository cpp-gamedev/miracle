# le2d

## 2D Game engine framework

[![Build Status](https://github.com/karnkaul/le2d/actions/workflows/ci.yml/badge.svg)](https://github.com/karnkaul/le2d/actions/workflows/ci.yml)

## Documentation

Documentation is hosted [here](https://karnkaul.github.io/le2d/).

## Contributing

Pull/merge requests are welcome.

**[Original repository](https://github.com/karnkaul/le2d)**
